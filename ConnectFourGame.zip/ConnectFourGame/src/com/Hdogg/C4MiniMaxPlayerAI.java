package com.Hdogg;

import java.util.Scanner;

public class C4MiniMaxPlayerAI {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Board b = new Board();
        boolean gameOver = false;
        System.out.println(b.toString(true));
        boolean turn = Board.PLAYER_1_TURN;
        boolean player = true;
        while (!gameOver) {
            int selection;
            if (turn == player) {
                System.out.printf("Enter your move: ", b.getNextTurn() == Board.PLAYER_1_TURN ? 1 : 2);
                do {
                    selection = input.nextInt();
                } while (!b.isValidMove(selection));
                System.out.println();
                if (b.isValidMove(selection)){
                    b.placePiece(selection, 2);
                }
                if (b.didPlayerWin(2)){
                    System.out.println("\u001B[34m" + "Player 2 wins");
                    gameOver = true;
                }
                turn = false;
            } else {
                System.out.println("player 1 AI makes a move");
                System.out.println("Score:" + b.minimax(9, Integer.MIN_VALUE, Integer.MAX_VALUE, true));
                System.out.println("Column: " + b.getColumnScore().getColumn());
                selection = b.getColumnScore().getColumn();
                if(b.isValidMove(selection)) {
                    b.placePiece(selection, 1);
                }
                if(b.didPlayerWin(2)) {
                    System.out.println("\u001B[31m" + "Player 1 wins");
                    gameOver = true;
                }
                else if(b.didPlayerWin(1)) {
                    System.out.println("\u001B[31m" + "Player 2 wins");
                    gameOver = true;
                }
                turn = true;
            }
            if (b.isFull()) {
                System.out.println("Draw");
                gameOver = true;
            }
            System.out.println(b.toString(true));
        }
    }
}
