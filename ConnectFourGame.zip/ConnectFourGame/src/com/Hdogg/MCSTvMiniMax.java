package com.Hdogg;

import java.util.concurrent.TimeUnit;

public class MCSTvMiniMax {
    public static void main(String[] args) {
        int miniMaxMoves = 0;
        int monteCarloMoves = 0;

        int miniMaxLosses = 0;
        int monteCarloLosses = 0;

        long startTimeForMiniMax = 0;
        long endTimeForMiniMax = 0;
        long miniMaxDuration = 0;

        long startTimeForMonteCarlo = 0;
        long endTimeForMonteCarlo = 0;
        long monteCarloDuration = 0;

        int noOfGames = 100;

        int miniMaxDepth = 9;
        int monteCarloTime = 2;

        for (int i = 0; i < noOfGames; i++) {
            System.out.println("\n\nGame #" + (i+1) + ": ");
            final long GIVEN_TIME = TimeUnit.SECONDS.toNanos(args.length > 0 ? Integer.parseInt(args[0]) : monteCarloTime);
            Board board = new Board(5, 4);
            MCSTBrain monteCarloAI = new MCSTBrain(board, GIVEN_TIME);
            int lastPlayer = 0;
            while (board.currentGameState() == Board.ONGOING) {
                System.out.println("\n\n" + board.toString(false));
                int moveColumn;
                if (board.getNextTurn() == Board.PLAYER_1_TURN) {  // Currently MiniMax is first, just put a ! here to make monte carlo start first
                    System.out.println("player 2 AI makes a move");  // depth = 9 normally
                    startTimeForMiniMax = System.nanoTime();
                    System.out.println("Score:" + board.minimax(miniMaxDepth, Integer.MIN_VALUE, Integer.MAX_VALUE, true));
                    System.out.println("Column: " + board.getColumnScore().getColumn());
                    moveColumn = board.getColumnScore().getColumn();
                    endTimeForMiniMax = System.nanoTime();
                    miniMaxMoves++;
                    if (board.isValidMove(moveColumn)) {
                        board.placePiece(moveColumn, 1);
                        lastPlayer = 1;
                    }
                    if (board.didPlayerWin(1)) {
                        System.out.println("\u001B[31m" + "Player 2 wins");
                        break;
                    } else if (board.didPlayerWin(2)) {
                        System.out.println("\u001B[31m" + "Player 1 wins");
                        break;
                    }
                    monteCarloAI.update(moveColumn);
                } else {
                    System.out.print("Player 1 AI determining move: ");
                    startTimeForMonteCarlo = System.nanoTime();
                    moveColumn = monteCarloAI.getOptimalMove();
                    endTimeForMonteCarlo = System.nanoTime();
                    monteCarloMoves++;
                    System.out.println(moveColumn);
                    board.placePiece(moveColumn, 2);
                    lastPlayer = 2;
                    monteCarloAI.update(moveColumn);
                }

                miniMaxDuration += (endTimeForMiniMax - startTimeForMiniMax) / 1000000;
                monteCarloDuration += (endTimeForMonteCarlo - startTimeForMonteCarlo) / 1000000;

                board.setNextTurn(!board.getNextTurn());

                if (board.isFull()) {
                    System.out.println("\n\n" + board.toString(false));
                    System.out.println("Tie");
                    //lastPlayer = -1;
                    break;
                }
            }
            //if (lastPlayer != -1) {
                if (lastPlayer == 1)
                    monteCarloLosses++;
                else
                    miniMaxLosses++;
            //}
            System.out.println("#of MiniMax Losses: " + miniMaxLosses);
            System.out.println("#of MonteCarlo Losses: " + monteCarloLosses);
        }

        System.out.println("The # of times MiniMax won is: " + (noOfGames - miniMaxLosses));
        System.out.println("The unbeatable % of MiniMax with depth " + miniMaxDepth + " is: " + 100.0 * ((noOfGames - miniMaxLosses) / (noOfGames * 1.0)));
        System.out.println("On average, MiniMax with depth of " + miniMaxDepth + " takes: " + (miniMaxDuration / miniMaxMoves) * 1.0 + " milliseconds to make a move");

        System.out.println("The # of times MonteCarlo won is: " + (noOfGames - monteCarloLosses));
        System.out.println("The unbeatable % of MonteCarlo on " + monteCarloTime + " second is: " + 100.0 * ((noOfGames - monteCarloLosses) / (noOfGames * 1.0)));
        System.out.println("On average, MonteCarlo with " + monteCarloTime + " second takes: " + (monteCarloDuration / monteCarloMoves) * 1.0 + " milliseconds to make a move");
    }
}
