package com.Hdogg;

// The connect 4 board state

import java.util.ArrayList;
import java.util.Random;

public class Board {
    // Start with implementing the MCST with the decision timer and then move to the mini max with alpha beta and depth selector
    public final int height;
    public final int width;
    private int[][] board;
    private boolean nextTurn;

    // board contents
    public static final int EMPTY_SLOT = 0;
    public static final int PLAYER_1_DISK = 1;
    public static final int PLAYER_2_DISK = 2;

    // turns
    public static final boolean PLAYER_1_TURN = true;

    // game state
    public static final int ONGOING = 0;
    public static final int PLAYER_1_WON = 1;
    public static final int PLAYER_2_WON = 2;
    public static final int TIE = 3;

    public Board(int width, int height) {
        this.width = width;
        this.height = height;
        board = new int[height][width]; // default all 0
        nextTurn = PLAYER_1_TURN;
    }

    public Board() {
        this(7, 6);
    }

    //remove
    public Board(int[][] contents, boolean nextTurn) {
        this(contents[0].length, contents.length);
        loadContents(contents);
        this.nextTurn = nextTurn;
    }

    public boolean checkValidPlacement(int column) {
        return column >= 0 && column < width && board[0][column] == 0;
    }

    public boolean place(int column) {
        int disk = (nextTurn == PLAYER_1_TURN) ? PLAYER_1_DISK : PLAYER_2_DISK;
        if(!checkValidPlacement(column))
            return false;
        int diskHeight = height - 1;
        while(board[diskHeight][column] != EMPTY_SLOT)
            diskHeight--;
        board[diskHeight][column] = disk;
        nextTurn = !nextTurn;
        return true;
    }

    public Board getNextState(int column) {
        Board next = this.copy();
        next.place(column);
        return next;
    }

    //remove
    public int[][] getContents() {
        int[][] contentsCopy = new int[height][width];
        for(int i = 0; i < height; i++)
            for(int j = 0; j < width; j++)
                contentsCopy[i][j] = board[i][j];
        return contentsCopy;
    }

    //remove
    public void loadContents(int[][] contents) {
        for(int i = 0; i < height; i++)
            for(int j = 0; j < width; j++)
                board[i][j] = contents[i][j];
    }

    public Board copy() {
        return new Board(board, this.nextTurn);
    }

    //checkWinCondition()
    public boolean didPlayerWin(int playerDisk) {
        int height = board.length;
        int width = board[0].length;
        // check horizontal - (use width - 3) to allow for easily variable board sizes
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width - 3; j++) {
                for (int k = j; k < j + 4 && board[i][k] == playerDisk; k++) {
                    if (k == (j + 3)) {
                        return true;
                    }
                }
            }
        }

        // check vertical - use (height - 3) to allow for easily variable board sizes
        for (int i = 0; i < height - 3; i++) {
            for (int j = 0; j < width; j++) {
                for (int k = i; k < i + 4 && board[k][j] == playerDisk; k++) {
                    if (k == (i + 3)) {
                        return true;
                    }
                }
            }
        }

        // check diagonal down right using (height - 3) and (width - 3) for easily variable board sizes
        for (int i = 0; i < height - 3; i++) {
            for (int j = 0; j < width - 3; j++) {
                for (int k = 0; k < 4 && board[i + k][j + k] == playerDisk; k++) {
                    if (k == 3) {
                        return true;
                    }
                }
            }
        }

        // check diagonal down using (height - 3) and starting from j = 3 for easily variable board sizes
        for (int i = 0; i < height - 3; i++) {
            for (int j = 3; j < width; j++) {
                for (int k = 0; k < 4 && board[i + k][j - k] == playerDisk; k++) {
                    if (k == 3) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isFull() {
        for(int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                if (board[i][j] == EMPTY_SLOT) {
                    return false;
                }
            }
        }
        return true;
    }

    // This was neater than full of ifs and elses
    public int currentGameState() {
        return this.didPlayerWin(PLAYER_1_DISK) ? PLAYER_1_WON
                : this.didPlayerWin(PLAYER_2_DISK) ? PLAYER_2_WON
                : this.isFull() ? TIE
                : ONGOING;
    }

    public boolean getNextTurn() {
        return nextTurn;
    }

    public void setNextTurn(boolean nextTurn) {
        this.nextTurn = nextTurn;
    }

    public String toString(boolean isMiniMax) {
        String result = "|-";
        for(int j = 0; j < width; j++) {
            result += "--|-";
        }
        result = result.substring(0, result.length()-1) + "\n";
        for(int i = 0; i < height; i++) {
            result += "| ";
            if (isMiniMax) {  // print upside dwon for minimax
                for (int j = 0; j < width; j++) {
                    result += (board[i][j] == EMPTY_SLOT ? " " : (board[i][j] == 1 ? "2" : "1")) + " | ";
                }
            }
            else {
                for (int j = 0; j < width; j++) {
                    result += (board[height-(i+1)][j] == EMPTY_SLOT ? " " : (board[height-(i+1)][j] == 1 ? "2" : "1")) + " | ";
                }
            }
            result = result.substring(0, result.length()-1);
            result += "\n|-";
            for(int j = 0; j < width; j++) {
                result += "--|-";
            }
            result = result.substring(0, result.length()-1);
            result += "\n";
        }
        result+="  0   1   2   3   4   5   6  ";
        return result.substring(0, result.length()-1);
    }

    public int[][] getBoard() {
        return board;
    }

    /* MiniMax Required Methods */
    private ColumnScoreForMiniMax columnScore = new ColumnScoreForMiniMax();

    //Pre-conditions: player move generated
    //Post-conditions: inputs the player move on the boardmatrix and perft board
    public void inputMove(int player, int move){
        placePiece(move, player);
    }


    //Pre-conditions: board has been created, column to place piece has been selected
    //Post-conditions: puts player piece into selected board position
    public int placePiece(int column, int playerMove){
        for(int i = 0; i < height; i++){
            if(board[i][column] == 0){
                board[i][column] = playerMove;
                return i;
            }
        }
        return 0;
    }

    //Pre-conditions: board has pieces on it
    //Post-conditions: removes a player piece from the board
    public void removePiece(int row, int column){
        board[row][column] = 0;
    }

    //Pre-conditions: board has been created, board state inputed
    //Post-conditions: board is evaluated and value for board state is returned as an integer value
    public int evaluatePos(){
        int value = 0;

        //check the board horizontally for all possible arrangements of pieces and add weighting if boardstate is discovered
        for(int i = 0; i<height; i++){
            for(int j = 0; j< width - 3; j++){

                int myPieceCount = 0;
                int oppPieceCount = 0;
                int emptyCount = 0;
                for (int k = 0; k < 4; k++) {
                    if (board[i][j+k] == 1) {
                        myPieceCount++;
                    } else if(board[i][j+k] == 0) {
                        emptyCount++;
                    } else if(board[i][j+k] == 2) {
                        oppPieceCount++;
                    }
                }
                value += valueCount(myPieceCount, oppPieceCount, emptyCount);
            }
        }

        //check the board vertically for all possible arrangements of pieces and add weighting if boardstate is discovered
        for (int i = 0; i< height - 3; i++) {
            for (int j = 0; j< width; j++) {

                int myPieceCount = 0;
                int oppPieceCount = 0;
                int emptyCount = 0;
                for (int k = 0; k < 4; k++) {
                    if (board[i+k][j] == 1) {
                        myPieceCount++;
                    } else if(board[i+k][j] == 0) {
                        emptyCount++;
                    } else if(board[i+k][j] == 2) {
                        oppPieceCount++;
                    }
                }
                value += valueCount(myPieceCount, oppPieceCount, emptyCount);
            }
        }

        //check the boards negative diagonals for all possible arrangements of pieces and add weighting if boardstate is discovered
        for (int i = 0; i< height - 3; i++) {
            for (int j = 3; j < width; j++) {

                int myPieceCount = 0;
                int oppPieceCount = 0;
                int emptyCount = 0;
                for (int k = 0; k < 4; k++) {
                    if (board[i+k][j-k] == 1) {
                        myPieceCount++;
                    } else if(board[i+k][j-k] == 0) {
                        emptyCount++;
                    } else if(board[i+k][j-k] == 2) {
                        oppPieceCount++;
                    }
                }
                value += valueCount(myPieceCount, oppPieceCount, emptyCount);
            }
        }

        //check the boards positive diagonals for all possible arrangements of pieces and add weighting if boardstate is discovered
        for (int i = 0; i< height - 3; i++) {
            for (int j = 0; j< width - 3; j++) {

                int myPieceCount = 0;
                int oppPieceCount = 0;
                int emptyCount = 0;
                for (int k = 0; k < 4; k++) {
                    if (board[i+k][j+k] == 1) {
                        myPieceCount++;
                    } else if(board[i+k][j+k] == 0) {
                        emptyCount++;
                    } else if(board[i+k][j+k] == 2) {
                        oppPieceCount++;
                    }
                }
                value += valueCount(myPieceCount, oppPieceCount, emptyCount);
            }
        }

        //add a weighting if the boardstate contains peices in the centre column
        for (int i = 0; i < height; i++) {
            if (board[i][3] == 1) {
                value += 2;
            }
        }
        return value;
    }

    //Pre-conditions: evaluatePos has called the function
    //Post-conditions: accumulates values based on heuristic and outputs a value,
    //scores here can be adjusted to create better or worse AI
    public int valueCount(int myPieceCount, int oppPieceCount, int emptyCount){
        int value = 0;

        //heuristic 1: 1 empty location and 3 AI pieces in a row
        if(myPieceCount == 3 && emptyCount == 1) {
            value += 15;
            //heuristic 2: 2 empty locations and 2 AI pieces in a row
        }else if(myPieceCount == 2 && emptyCount == 2){
            value += 5;
        }

        //heuristic 1: 1 empty location and 3 opponent pieces in a row
        if(oppPieceCount == 3 && emptyCount == 1){
            value -= 10;
            //heuristic 1: 2 empty locations and 2 opponent pieces in a row
        }else if(oppPieceCount == 2 && emptyCount == 2){
            value -= 3;
        }
        return value;
    }

    //Pre-conditions: board state has been created
    //Post-conditions: evaluate board state and return a boolean if a end of game condition has been satisfied
    public Boolean endOfGame(){
        return didPlayerWin(1) || didPlayerWin(2) || getOpenLocations().size() == 0;
    }


    //Pre-conditions: board state has been created
    //Post-conditions: creates an array list of open locations to place a piece
    public ArrayList<Integer> getOpenLocations(){
        ArrayList<Integer> openLocations= new ArrayList<Integer>();
        for(int i = 0; i < width; i++){
            if(board[height-1][i] == 0){
                openLocations.add(i);
            }
        }
        return openLocations;
    }

    public Boolean isValidMove(int move) {
        return move >= 0 && move < 7 && board[height-1][move] == 0;
    }

    // Assumes board state is initialized, return a column and value best fit as determined by the evaluation function
    public int minimax(int depth, int alpha, int beta, Boolean maximizingPlayer){
        ArrayList<Integer> openLocations = getOpenLocations(); // create a current list of open locations to place a piece based on the board state
        // check if current state is an end of game condition
        if (endOfGame()) {
            if (didPlayerWin(1)) {
                return Integer.MAX_VALUE; // return large integer if board state returns player win
            } else if (didPlayerWin(2)) {
                return Integer.MIN_VALUE; // return large negative integer if board state returns opponent win
            } else {
                return 0; // return 0 if state is a draw
            }
        } else if(depth == 0) {
            return evaluatePos(); // if leaf node is not a win condition return the evaluation of the board state at depth set
        }
        // if it is the AI players move
        if (maximizingPlayer) {
            int value = Integer.MIN_VALUE;
            int column = openLocations.get(new Random(System.currentTimeMillis()).nextInt(openLocations.size()));  // set column to a random open location
            // loop through open locations where a piece could be placed which serve as the child nodes to the current node
            for (int i = 0; i < openLocations.size(); i++){
                int row = placePiece(openLocations.get(i), 1);  // place a piece in an open location
                int tempValue = minimax(depth -1, alpha, beta, false); // set temp value to the value of the recursion, change to minimising player
                // check if the value of the current child is greater then the stored value
                if (tempValue > value){
                    value = tempValue; // update the value with tempValue
                    column = openLocations.get(i); // set column to current location
                }
                removePiece(row, openLocations.get(i)); // finally remove the placed piece for future recursions
                // alpha-beta pruning
                alpha = Integer.max(value, alpha);
                if (alpha >= beta){
                    i = 7;
                }
            }
            // set value and column to the maximising column and value and return the maximising value
            columnScore.setColumn(column);
            columnScore.setScore(value);
            return value;
        }
        // else if it is the opponents move
        else {
            int value = Integer.MAX_VALUE;
            int column = openLocations.get(new Random(System.currentTimeMillis()).nextInt(openLocations.size())); //set column to a random open location
            // loop through open locations where a piece could be placed which serve as the child nodes to the current node
            for (int i = 0; i < openLocations.size(); i++){
                int row = placePiece(openLocations.get(i), 2);  // place a piece in an open location
                int tempValue = minimax(depth -1, alpha, beta, true); // set temp value to the value of the recursion, change to maximising player
                // check if the value of the current child is less then the stored value
                if (tempValue < value){
                    value = tempValue;  // update the value with tempValue
                    column = openLocations.get(i); // set column to current location
                }
                removePiece(row, openLocations.get(i)); // finally remove the placed piece for future recursions
                // alpha-beta pruning
                beta = Integer.min(value, beta);
                if (alpha >= beta){
                    i = 7;
                }
            }
            columnScore.setColumn(column);
            columnScore.setScore(value);
            return value;
        }
    }

    // getter for
    public ColumnScoreForMiniMax getColumnScore(){
        return columnScore;
    }
}
