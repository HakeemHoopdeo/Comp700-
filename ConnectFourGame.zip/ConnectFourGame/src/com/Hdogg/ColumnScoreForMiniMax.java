package com.Hdogg;

public class ColumnScoreForMiniMax {
    private int column;
    private int score;

    public ColumnScoreForMiniMax() { score = 0; }

    public int getColumn() { return column; }

    public void setColumn(int column) { this.column = column; }

    public int getScore() { return score; }

    public void setScore(int score) { this.score = score; }
}
