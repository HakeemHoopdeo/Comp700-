package com.Hdogg;

import java.util.Scanner;

public class SimpleCustomAILeftOnlyvMiniMax {
    public static void main(String[] args) {
        Board board = new Board();
        int moveColumn = 0;
        Scanner in = new Scanner(System.in);
        while (board.currentGameState() == Board.ONGOING) {
            System.out.println("\n\n"+board.toString(false));
            if (board.getNextTurn() == Board.PLAYER_1_TURN) {  // Currently MiniMax is first, just put a ! here to make monte carlo start first
                /*System.out.println("player 2 AI makes a move");  // depth = 9 normally
                System.out.println("Score:" + board.minimax(9, Integer.MIN_VALUE, Integer.MAX_VALUE, true));
                System.out.println("Column: " + board.getColumnScore().getColumn());
                moveColumn = board.getColumnScore().getColumn();*/
                System.out.print("User plays: ");
                moveColumn = in.nextInt();
                if (board.isValidMove(moveColumn)){
                    board.placePiece(moveColumn, 1);
                }
                if (board.didPlayerWin(2)){
                    System.out.println("\u001B[31m" + "Player 1 wins");
                    System.out.println("\n\n"+board.toString(false));
                    break;
                }
                else if (board.didPlayerWin(1)){
                    System.out.println("\u001B[31m" + "Player 2 wins");
                    System.out.println("\n\n"+board.toString(false));
                    break;
                }
            }
            else {
                System.out.print("Player 1 AI determining move: ");
                //Left Only portion
                    if (moveColumn == 0)
                        moveColumn = board.width - 1;
                    else
                        moveColumn--;
                    while (true) {
                        if (board.isValidMove(moveColumn)) {
                            board.placePiece(moveColumn, 2);
                            break;
                        }
                        moveColumn--;
                    }
                System.out.println(moveColumn);
            }

            board.setNextTurn(!board.getNextTurn());

            if (board.isFull()) {
                System.out.println("\n\n"+board.toString(false));
                System.out.println("Tie");
                break;
            }
        }
    }
}
