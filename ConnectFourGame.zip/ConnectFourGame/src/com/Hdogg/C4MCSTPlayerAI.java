package com.Hdogg;

// Single player Connect 4 against Monte Carlo Tree Search AI

//import com.Hdogg.MCST.Connect4AI;
//import com.Hdogg.MCST.Connect4Board;

import java.util.concurrent.TimeUnit;
import java.util.Scanner;

public class C4MCSTPlayerAI {
    public static void main(String[] args) {
        final long GIVEN_TIME = TimeUnit.SECONDS.toNanos(args.length > 0 ? Integer.parseInt(args[0]) : 5);
        Scanner in = new Scanner(System.in);
        Board board = new Board();
        //boolean turn = Board.PLAYER_1_TURN;
        MCSTBrain monteCarloAI = new MCSTBrain(board, GIVEN_TIME);
        while (board.currentGameState() == Board.ONGOING) {
            System.out.println("\n\n" + board.toString(false));
            int moveColumn;
            do {
                if (board.getNextTurn() == Board.PLAYER_1_TURN) {
                    System.out.printf("Enter your move: ", board.getNextTurn() == Board.PLAYER_1_TURN ? 1 : 2);
                    moveColumn = in.nextInt();
                }
                else {
                    System.out.print("AI determining move: ");
                    moveColumn = monteCarloAI.getOptimalMove();
                    System.out.println(moveColumn);
                }
            } while (!board.checkValidPlacement(moveColumn));
            board.place(moveColumn);
            monteCarloAI.update(moveColumn);
        }
        int gameState = board.currentGameState();
        System.out.println("\n\n\n\n\n");
        System.out.println(board.toString(false));
        switch (gameState) {
            case Board.PLAYER_1_WON:
                System.out.println("You won.\n");
                break;
            case Board.PLAYER_2_WON:
                System.out.println("AI won.\n");
                break;
            default:
                System.out.println("Tie.\n");
                break;
        }
    }
}
